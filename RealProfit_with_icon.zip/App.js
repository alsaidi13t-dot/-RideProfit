import './ui/native-shim';
import React from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';

import { ThemeProvider, useTheme } from './ui/theme';
import { AppProvider } from './store/AppContext';

import CalculatorScreen from './screens/CalculatorScreen';
import SettingsScreen from './screens/SettingsScreen';
import HistoryScreen from './screens/HistoryScreen';
import TripDetailScreen from './screens/TripDetailScreen';
import ProScreen from './screens/ProScreen';

import { guardScreen } from './ui/theme';
const Tab = createBottomTabNavigator();
const CalcStack = createStackNavigator();
const HistoryStack = createStackNavigator();
const ProStack = createStackNavigator();

function useStackOptions() {
  const t = useTheme();
  return {
    headerStyle: {
      backgroundColor: t.bg,
      elevation: 0,
      shadowOpacity: 0,
      borderBottomWidth: 0,
    },
    headerTitleStyle: [t.font.headline, { color: t.text }],
    headerTintColor: t.accent,
    headerBackTitleVisible: false,
    cardStyle: { flex: 1, backgroundColor: t.bg },
  };
}

function CalculatorNav() {
  const opts = useStackOptions();
  return (
    <CalcStack.Navigator screenOptions={{ ...opts, cardStyle: { ...opts.cardStyle, flex: 1 } }}>
      <CalcStack.Screen name="CalculatorHome" component={guardScreen(CalculatorScreen, "CalculatorHome")} options={{ headerShown: false }} />
      <CalcStack.Screen name="Settings" component={guardScreen(SettingsScreen, "Settings")} options={{ title: 'Your Numbers' }} />
    </CalcStack.Navigator>
  );
}

function HistoryNav() {
  const opts = useStackOptions();
  return (
    <HistoryStack.Navigator screenOptions={{ ...opts, cardStyle: { ...opts.cardStyle, flex: 1 } }}>
      <HistoryStack.Screen name="HistoryHome" component={guardScreen(HistoryScreen, "HistoryHome")} options={{ headerShown: false }} />
      <HistoryStack.Screen name="TripDetail" component={guardScreen(TripDetailScreen, "TripDetail")} options={{ title: 'Trip Breakdown' }} />
    </HistoryStack.Navigator>
  );
}

function ProNav() {
  const opts = useStackOptions();
  return (
    <ProStack.Navigator screenOptions={{ ...opts, cardStyle: { ...opts.cardStyle, flex: 1 } }}>
      <ProStack.Screen name="ProHome" component={guardScreen(ProScreen, "ProHome")} options={{ headerShown: false }} />
      <ProStack.Screen name="ProSettings" component={guardScreen(SettingsScreen, "ProSettings")} options={{ title: 'Your Numbers' }} />
    </ProStack.Navigator>
  );
}

function RootTabs() {
  const t = useTheme();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: t.accent,
        tabBarInactiveTintColor: t.textMuted,
        tabBarStyle: {
          backgroundColor: t.surface,
          borderTopColor: t.border,
          borderTopWidth: StyleSheetHairline,
          height: 84,
          paddingTop: 8,
          paddingBottom: 26,
        },
        tabBarLabelStyle: [t.font.caption],
        tabBarIcon: ({ color, size, focused }) => {
          const map = {
            Calculator: focused ? 'calculator' : 'calculator-outline',
            History: focused ? 'time' : 'time-outline',
            Pro: focused ? 'flash' : 'flash-outline',
          };
          return <Ionicons name={map[route.name] || 'ellipse-outline'} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Calculator" component={guardScreen(CalculatorNav, "Calculator")} />
      <Tab.Screen name="History" component={guardScreen(HistoryNav, "History")} />
      <Tab.Screen name="Pro" component={guardScreen(ProNav, "Pro")} />
    </Tab.Navigator>
  );
}

const StyleSheetHairline = 0.5;

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <ThemeProvider
          theme="midnight"
          accent="#F5A623"
          accents={['#F5A623', '#2ECC71', '#FF5C4D', '#4CC2FF', '#B07CFF']}
        >
          <AppProvider>
            <StatusBar style="light" />
            <NavigationContainer>
              <RootTabs />
            </NavigationContainer>
          </AppProvider>
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
