import React, { useEffect, useRef, useState } from 'react';
import { Animated, Text } from 'react-native';

// A money-safe count-up: keeps cents, handles negatives, never renders NaN.
export default function CountUp({ value = 0, style, prefix = '$', suffix = '', decimals = 2, duration = 450 }) {
  const safe = Number.isFinite(Number(value)) ? Number(value) : 0;
  const anim = useRef(new Animated.Value(safe)).current;
  const [display, setDisplay] = useState(safe);

  useEffect(() => {
    const id = anim.addListener(({ value: v }) => {
      setDisplay(Number.isFinite(v) ? v : 0);
    });
    return () => anim.removeListener(id);
  }, [anim]);

  useEffect(() => {
    Animated.timing(anim, {
      toValue: safe,
      duration,
      useNativeDriver: false,
    }).start();
  }, [safe, anim, duration]);

  const v = Number.isFinite(display) ? display : 0;
  const text = `${v < 0 ? '-' : ''}${prefix}${Math.abs(v).toFixed(decimals)}${suffix}`;

  return <Text style={style} numberOfLines={1}>{text}</Text>;
}
