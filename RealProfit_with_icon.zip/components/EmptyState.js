import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { useTheme } from '../ui/theme';

export default function EmptyState({ icon = 'document-text-outline', title, body }) {
  const t = useTheme();

  return (
    <View style={styles.container}>
      <View style={[styles.iconWrap, { backgroundColor: t.surfaceAlt || t.surface }]}>
        <Ionicons name={icon} size={24} color={t.textMuted} />
      </View>
      {!!title && <Text style={[t.font.headline, { color: t.text, marginTop: 12 }]}>{title}</Text>}
      {!!body && (
        <Text style={[t.font.caption, { color: t.textMuted, marginTop: 4, textAlign: 'center' }]}>
          {body}
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 24,
    paddingHorizontal: 16,
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
