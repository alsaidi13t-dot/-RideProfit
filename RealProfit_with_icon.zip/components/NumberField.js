import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ui/theme';
import { withAlpha } from '../lib/calc';

export default function NumberField({
  label,
  hint,
  icon,
  iconColor,
  value,
  onChangeText,
  prefix,
  suffix,
  placeholder,
  last = false,
}) {
  const t = useTheme();
  const [focused, setFocused] = useState(false);
  const tint = iconColor || t.accent;

  return (
    <View
      style={[
        styles.row,
        {
          paddingHorizontal: t.spacing.md,
          borderBottomWidth: last ? 0 : StyleSheet.hairlineWidth,
          borderBottomColor: t.border,
          backgroundColor: focused ? withAlpha(tint, 0.06) : 'transparent',
        },
      ]}
    >
      {icon ? (
        <View style={[styles.badge, { backgroundColor: withAlpha(tint, 0.16), borderRadius: t.radius.sm }]}>
          <Ionicons name={icon} size={16} color={tint} />
        </View>
      ) : null}
      <View style={{ flex: 1 }}>
        <Text style={StyleSheet.flatten([t.font.body, { color: t.text }])} numberOfLines={1}>
          {label}
        </Text>
        {hint ? (
          <Text style={StyleSheet.flatten([t.font.caption, { color: t.textMuted, marginTop: 1 }])} numberOfLines={1}>
            {hint}
          </Text>
        ) : null}
      </View>
      <View style={styles.inputWrap}>
        {prefix ? (
          <Text style={StyleSheet.flatten([t.font.headline, { color: value ? t.text : t.textMuted }])}>{prefix}</Text>
        ) : null}
        <TextInput
          value={String(value ?? '')}
          onChangeText={onChangeText}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder={placeholder}
          placeholderTextColor={withAlpha(t.textMuted, 0.6)}
          keyboardType="decimal-pad"
          returnKeyType="done"
          selectTextOnFocus
          style={StyleSheet.flatten([
            t.font.headline,
            { color: t.text, minWidth: 54, textAlign: 'right', paddingVertical: 8 },
          ])}
        />
        {suffix ? (
          <Text style={StyleSheet.flatten([t.font.footnote, { color: t.textMuted, marginLeft: 4, width: 34 }])}>
            {suffix}
          </Text>
        ) : (
          <View style={{ width: 0 }} />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 56,
  },
  badge: {
    width: 30,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
});
