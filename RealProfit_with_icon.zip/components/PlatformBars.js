import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Rect } from 'react-native-svg';
import { useTheme } from '../ui/theme';
import { fmt, withAlpha } from '../lib/calc';
import { platformColor } from '../lib/platforms';

// Horizontal $/hr comparison bars, drawn as real vectors.
export default function PlatformBars({ rows = [], threshold = 20 }) {
  const t = useTheme();
  const [w, setW] = useState(0);
  const max = Math.max(threshold, ...rows.map((r) => Math.max(0, r.value || 0)), 1);

  return (
    <View>
      {rows.map((r) => {
        const c = platformColor(t, r.id);
        const ratio = max > 0 ? Math.min(1, Math.max(0, (r.value || 0) / max)) : 0;
        const barW = Math.max(2, w * ratio);
        const markX = max > 0 ? (threshold / max) * w : 0;
        return (
          <View key={r.id} style={styles.row}>
            <Text style={StyleSheet.flatten([t.font.footnote, { color: t.text, width: 76 }])} numberOfLines={1}>
              {r.name}
            </Text>
            <View style={{ flex: 1 }} onLayout={(e) => setW(e.nativeEvent.layout.width)}>
              {w > 0 ? (
                <Svg width={w} height={14}>
                  <Rect x={0} y={3} width={w} height={8} rx={4} fill={t.surfaceAlt} />
                  <Rect x={0} y={3} width={barW} height={8} rx={4} fill={c} />
                  <Rect x={Math.min(w - 1.5, Math.max(0, markX))} y={0} width={1.5} height={14} fill={withAlpha(t.text, 0.45)} />
                </Svg>
              ) : null}
            </View>
            <Text
              style={StyleSheet.flatten([t.font.footnote, { color: t.text, width: 66, textAlign: 'right' }])}
              numberOfLines={1}
            >
              {fmt(r.value, 2)}/hr
            </Text>
          </View>
        );
      })}
      <Text style={StyleSheet.flatten([t.font.caption, { color: t.textMuted, marginTop: 6 }])}>
        Average net per hour by platform. The vertical mark is your {fmt(threshold, 0)}/hr target.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 12, gap: 8 },
});
