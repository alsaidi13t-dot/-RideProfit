import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useTheme } from '../ui/theme';
import { PLATFORMS, platformColor } from '../lib/platforms';
import { withAlpha } from '../lib/calc';

export default function PlatformPicker({ value, onChange }) {
  const t = useTheme();
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: t.spacing.md, gap: 8 }}
    >
      {PLATFORMS.map((p) => {
        const active = p.id === value;
        const c = platformColor(t, p.id);
        return (
          <Pressable
            key={p.id}
            onPress={() => {
              Haptics.selectionAsync();
              onChange && onChange(p.id);
            }}
            style={({ pressed }) => [
              styles.chip,
              {
                borderRadius: t.radius.pill,
                backgroundColor: active ? withAlpha(c, 0.18) : t.surface,
                borderColor: active ? c : t.border,
                opacity: pressed ? 0.75 : 1,
              },
            ]}
          >
            <Ionicons name={p.icon} size={15} color={active ? c : t.textMuted} />
            <Text
              style={StyleSheet.flatten([
                t.font.label,
                { color: active ? t.text : t.textMuted, marginLeft: 6 },
              ])}
            >
              {p.name}
            </Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    height: 36,
    borderWidth: 1,
    marginRight: 8,
  },
});
