import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useTheme } from '../ui/theme';

export default function Segmented({ options = [], value, onChange, style }) {
  const t = useTheme();
  const [w, setW] = useState(0);
  const idx = Math.max(0, options.findIndex((o) => o.value === value));
  const anim = useRef(new Animated.Value(idx)).current;

  useEffect(() => {
    Animated.spring(anim, {
      toValue: idx,
      useNativeDriver: true,
      friction: 9,
      tension: 90,
    }).start();
  }, [idx, anim]);

  const count = options.length || 1;
  const segW = w > 0 ? (w - 4) / count : 0;

  return (
    <View
      onLayout={(e) => setW(e.nativeEvent.layout.width)}
      style={[
        {
          flexDirection: 'row',
          backgroundColor: t.surfaceAlt,
          borderRadius: t.radius.pill,
          padding: 2,
          height: 36,
          alignItems: 'center',
        },
        style,
      ]}
    >
      {segW > 0 ? (
        <Animated.View
          style={{
            position: 'absolute',
            left: 2,
            top: 2,
            bottom: 2,
            width: segW,
            borderRadius: t.radius.pill,
            backgroundColor: t.accent,
            transform: [{ translateX: Animated.multiply(anim, segW) }],
          }}
        />
      ) : null}
      {options.map((o) => {
        const active = o.value === value;
        return (
          <Pressable
            key={String(o.value)}
            onPress={() => {
              if (o.value === value) return;
              Haptics.selectionAsync();
              onChange && onChange(o.value);
            }}
            style={({ pressed }) => [
              styles.seg,
              { opacity: pressed ? 0.7 : 1 },
            ]}
            hitSlop={6}
          >
            <Text
              numberOfLines={1}
              style={StyleSheet.flatten([
                t.font.label,
                { color: active ? t.onAccent : t.textMuted, textAlign: 'center' },
              ])}
            >
              {o.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  seg: {
    flex: 1,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
