import React, { useCallback, useEffect, useRef, useState } from 'react';
import { PanResponder, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useTheme } from '../ui/theme';

export default function Slider({
  value = 0,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  onComplete,
  color,
  disabled = false,
}) {
  const t = useTheme();
  const tint = color || t.accent;
  const [w, setW] = useState(0);
  const [val, setVal] = useState(value);
  const wRef = useRef(0);
  const valRef = useRef(value);

  useEffect(() => {
    valRef.current = value;
    setVal(value);
  }, [value]);

  const apply = useCallback((x) => {
    const width = wRef.current;
    if (!width) return;
    const ratio = Math.min(1, Math.max(0, x / width));
    const raw = min + ratio * (max - min);
    const stepped = Math.round(raw / step) * step;
    const clamped = Math.min(max, Math.max(min, Math.round(stepped * 100) / 100));
    if (clamped !== valRef.current) {
      valRef.current = clamped;
      setVal(clamped);
      Haptics.selectionAsync();
      onChange && onChange(clamped);
    }
  }, [min, max, step, onChange]);

  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => !disabled,
      onMoveShouldSetPanResponder: () => !disabled,
      onPanResponderGrant: (e) => apply(e.nativeEvent.locationX),
      onPanResponderMove: (e) => apply(e.nativeEvent.locationX),
      onPanResponderRelease: () => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        onComplete && onComplete(valRef.current);
      },
      onPanResponderTerminate: () => {
        onComplete && onComplete(valRef.current);
      },
    }),
  ).current;

  const range = max - min || 1;
  const ratio = Math.min(1, Math.max(0, (val - min) / range));
  const thumbX = w > 0 ? ratio * w : 0;

  return (
    <View
      {...pan.panHandlers}
      onLayout={(e) => {
        const width = e.nativeEvent.layout.width;
        wRef.current = width;
        setW(width);
      }}
      style={{ height: 44, justifyContent: 'center', opacity: disabled ? 0.45 : 1 }}
    >
      <View style={{ height: 6, borderRadius: 3, backgroundColor: t.surfaceAlt, overflow: 'hidden' }}>
        <View style={{ width: thumbX, height: 6, backgroundColor: tint }} />
      </View>
      <View
        pointerEvents="none"
        style={{
          position: 'absolute',
          left: Math.max(0, thumbX - 13),
          width: 26,
          height: 26,
          borderRadius: 13,
          backgroundColor: t.text,
          borderWidth: 3,
          borderColor: tint,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.3,
          shadowRadius: 6,
          elevation: 4,
        }}
      />
    </View>
  );
}
