import React, { useEffect, useRef, useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useTheme } from '../ui/theme';

const ITEM_H = 44;
const VISIBLE = 5;

function Column({ data, index, onIndex, width }) {
  const t = useTheme();
  const ref = useRef(null);
  const [active, setActive] = useState(index);

  useEffect(() => {
    setActive(index);
    const id = setTimeout(() => {
      ref.current?.scrollTo({ y: index * ITEM_H, animated: false });
    }, 30);
    return () => clearTimeout(id);
  }, [index]);

  const settle = (e) => {
    const y = e?.nativeEvent?.contentOffset?.y || 0;
    const i = Math.max(0, Math.min(data.length - 1, Math.round(y / ITEM_H)));
    if (i !== active) {
      setActive(i);
      Haptics.selectionAsync();
    }
    onIndex(i);
    ref.current?.scrollTo({ y: i * ITEM_H, animated: true });
  };

  return (
    <ScrollView
      ref={ref}
      style={{ width, height: ITEM_H * VISIBLE }}
      showsVerticalScrollIndicator={false}
      snapToInterval={ITEM_H}
      decelerationRate="fast"
      onMomentumScrollEnd={settle}
      onScrollEndDrag={settle}
      contentContainerStyle={{ paddingVertical: (ITEM_H * (VISIBLE - 1)) / 2 }}
    >
      {data.map((d, i) => {
        const dist = Math.abs(i - active);
        return (
          <View key={d} style={{ height: ITEM_H, alignItems: 'center', justifyContent: 'center' }}>
            <Text
              style={StyleSheet.flatten([
                t.font.title3,
                {
                  color: dist === 0 ? t.text : t.textMuted,
                  opacity: dist === 0 ? 1 : Math.max(0.25, 0.7 - dist * 0.2),
                },
              ])}
            >
              {d}
            </Text>
          </View>
        );
      })}
    </ScrollView>
  );
}

export default function TimePickerModal({ visible, hour = 20, minute = 30, onCancel, onConfirm }) {
  const t = useTheme();
  const hours = Array.from({ length: 12 }, (_, i) => String(i + 1));
  const minutes = Array.from({ length: 12 }, (_, i) => String(i * 5).padStart(2, '0'));
  const periods = ['AM', 'PM'];

  const initH = (hour % 12 === 0 ? 12 : hour % 12) - 1;
  const initM = Math.min(11, Math.round(minute / 5));
  const initP = hour >= 12 ? 1 : 0;

  const [hi, setHi] = useState(initH);
  const [mi, setMi] = useState(initM);
  const [pi, setPi] = useState(initP);

  useEffect(() => {
    if (visible) {
      setHi(initH);
      setMi(initM);
      setPi(initP);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  const done = () => {
    const h12 = hi + 1;
    let h24 = h12 % 12;
    if (pi === 1) h24 += 12;
    onConfirm && onConfirm(h24, mi * 5);
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onCancel}>
      <View style={styles.backdrop}>
        <Pressable style={{ flex: 1 }} onPress={onCancel} />
        <View style={{ backgroundColor: t.surface, borderTopLeftRadius: t.radius.xl, borderTopRightRadius: t.radius.xl, paddingBottom: 34 }}>
          <View style={[styles.head, { borderBottomColor: t.border, paddingHorizontal: t.spacing.md }]}>
            <Pressable onPress={onCancel} hitSlop={10}>
              <Text style={StyleSheet.flatten([t.font.body, { color: t.textMuted }])}>Cancel</Text>
            </Pressable>
            <Text style={StyleSheet.flatten([t.font.headline, { color: t.text }])}>Reminder time</Text>
            <Pressable onPress={done} hitSlop={10}>
              <Text style={StyleSheet.flatten([t.font.headline, { color: t.accent }])}>Done</Text>
            </Pressable>
          </View>
          <View style={styles.wheels}>
            <View
              pointerEvents="none"
              style={{
                position: 'absolute',
                left: 24,
                right: 24,
                top: (ITEM_H * (VISIBLE - 1)) / 2,
                height: ITEM_H,
                borderRadius: t.radius.md,
                backgroundColor: t.surfaceAlt,
              }}
            />
            <Column data={hours} index={hi} onIndex={setHi} width={70} />
            <Text style={StyleSheet.flatten([t.font.title3, { color: t.textMuted, marginHorizontal: 2 }])}>:</Text>
            <Column data={minutes} index={mi} onIndex={setMi} width={70} />
            <Column data={periods} index={pi} onIndex={setPi} width={70} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'flex-end' },
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  wheels: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
  },
});
