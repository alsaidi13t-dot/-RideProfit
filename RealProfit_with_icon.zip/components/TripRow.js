import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ui/theme';
import { getPlatform, platformColor } from '../lib/platforms';
import { fmt, num, withAlpha } from '../lib/calc';
import { verdictColors } from './VerdictChip';

export default function TripRow({ trip, onPress, last = false }) {
  const t = useTheme();
  const tr = trip || {};
  const p = getPlatform(tr.platform);
  const c = platformColor(t, tr.platform);
  const good = tr.verdict === 'good';
  const vc = verdictColors(t, good);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.row,
        {
          paddingHorizontal: t.spacing.md,
          borderBottomWidth: last ? 0 : StyleSheet.hairlineWidth,
          borderBottomColor: t.border,
          backgroundColor: pressed ? t.surfaceAlt : 'transparent',
        },
      ]}
    >
      <View style={[styles.icon, { backgroundColor: withAlpha(c, 0.16), borderRadius: t.radius.sm }]}>
        <Ionicons name={p.icon} size={17} color={c} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={StyleSheet.flatten([t.font.body, { color: t.text }])} numberOfLines={1}>
          {p.name}
        </Text>
        <Text style={StyleSheet.flatten([t.font.caption, { color: t.textMuted, marginTop: 2 }])} numberOfLines={1}>
          {fmt(num(tr.trip_pay))} pay · {num(tr.distance).toFixed(1)} mi · {Math.round(num(tr.minutes))} min
        </Text>
      </View>
      <View style={{ alignItems: 'flex-end' }}>
        <Text style={StyleSheet.flatten([t.font.headline, { color: vc }])}>{fmt(num(tr.net_profit))}</Text>
        <Text style={StyleSheet.flatten([t.font.caption, { color: t.textMuted, marginTop: 2 }])}>
          {fmt(num(tr.per_hour))}/hr
        </Text>
      </View>
      <Ionicons name="chevron-forward" size={16} color={withAlpha(t.textMuted, 0.7)} style={{ marginLeft: 6 }} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', minHeight: 62 },
  icon: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
});
