import React, { useEffect, useRef } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../ui/theme';
import { fmt, withAlpha } from '../lib/calc';

export function verdictColors(t, good) {
  const list = Array.isArray(t.accents) && t.accents.length >= 3 ? t.accents : [t.accent, t.success, t.danger];
  return good ? (list[1] || t.success) : (list[2] || t.danger);
}

export default function VerdictChip({ good, perHour = 0, threshold = 20, onLongPress, locked = false }) {
  const t = useTheme();
  const c = verdictColors(t, good);
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    pulse.setValue(0);
    Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: 180, useNativeDriver: true }),
      Animated.spring(pulse, { toValue: 0, friction: 5, tension: 120, useNativeDriver: true }),
    ]).start();
  }, [good, pulse]);

  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.04] });

  return (
    <Pressable onLongPress={onLongPress} delayLongPress={380} style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1 })}>
      <Animated.View
        style={{
          transform: [{ scale }],
          backgroundColor: withAlpha(c, 0.14),
          borderColor: withAlpha(c, 0.55),
          borderWidth: 1,
          borderRadius: t.radius.lg,
          padding: t.spacing.md,
        }}
      >
        <View style={styles.top}>
          <View style={styles.left}>
            <Ionicons name={good ? 'trending-up' : 'alert-circle'} size={20} color={c} />
            <Text style={StyleSheet.flatten([t.font.title3, { color: c, marginLeft: 8, letterSpacing: 0.5 }])}>
              {good ? 'GOOD TRIP' : 'LOW PROFIT'}
            </Text>
          </View>
          <Ionicons name={locked ? 'lock-closed-outline' : 'options-outline'} size={15} color={withAlpha(t.text, 0.4)} />
        </View>
        <Text style={StyleSheet.flatten([t.font.footnote, { color: t.textMuted, marginTop: 6 }])}>
          {fmt(perHour)}/hr against your {fmt(threshold, 0)}/hr target — hold to adjust
        </Text>
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  left: { flexDirection: 'row', alignItems: 'center' },
});
