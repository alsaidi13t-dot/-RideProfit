import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { useTheme } from '../ui/theme';
import { Screen, Card, Button } from '../ui/kit';
import { useApp } from '../store/AppContext';
import { computeTrip, num, DEFAULT_THRESHOLD } from '../lib/calc';
import { PLATFORMS } from '../lib/platforms';

import PlatformPicker from '../components/PlatformPicker';
import NumberField from '../components/NumberField';
import CountUp from '../components/CountUp';
import VerdictChip from '../components/VerdictChip';

export default function CalculatorScreen({ navigation }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { settings, addTrip, remaining, isPro, threshold } = useApp();

  const [platform, setPlatform] = useState(PLATFORMS[0]?.id || 'uber');
  const [pay, setPay] = useState('');
  const [distance, setDistance] = useState('');
  const [minutes, setMinutes] = useState('');
  const [saving, setSaving] = useState(false);

  const result = useMemo(() => {
    return computeTrip({
      pay: num(pay),
      distance: num(distance),
      minutes: num(minutes),
      gasPrice: num(settings.gas_price),
      mpg: num(settings.mpg),
      maintPerMile: num(settings.maint_per_mile),
    });
  }, [pay, distance, minutes, settings]);

  const canSave = num(pay) > 0 && num(distance) > 0 && num(minutes) > 0;
  const blocked = !isPro && remaining <= 0;

  const onSave = async () => {
    if (!canSave || saving) return;
    if (blocked) {
      Alert.alert('Daily limit reached', 'Upgrade to Pro for unlimited trip calculations.');
      return;
    }
    setSaving(true);
    try {
      const now = new Date();
      await addTrip({
        platform,
        trip_pay: num(pay),
        distance: num(distance),
        minutes: num(minutes),
        gas_price: num(settings.gas_price),
        mpg: num(settings.mpg),
        maint_per_mile: num(settings.maint_per_mile),
        fuel_cost: result.fuel,
        maint_cost: result.maint,
        total_expenses: result.expenses,
        net_profit: result.net,
        per_hour: result.perHour,
        per_mile: result.perMile,
        verdict: result.perHour >= threshold ? 'good' : 'low',
        day_key: now.toISOString().slice(0, 10),
        logged_at: now.toISOString(),
      });
      setPay('');
      setDistance('');
      setMinutes('');
    } catch (e) {
      Alert.alert('Could not save', e?.message || 'Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 16 }]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.headerRow}>
          <View>
            <Text style={[t.font.largeTitle, { color: t.text }]}>Gig Calculator</Text>
            <Text style={[t.font.subhead, { color: t.textMuted }]}>
              {isPro ? 'Unlimited calculations' : `${remaining} free calculation${remaining === 1 ? '' : 's'} left today`}
            </Text>
          </View>
          <TouchableOpacity onPress={() => navigation.navigate('Settings')} style={[styles.gearBtn, { backgroundColor: t.surface }]}>
            <Ionicons name="settings-outline" size={20} color={t.text} />
          </TouchableOpacity>
        </View>

        <Card style={{ marginTop: 16 }}>
          <Text style={[t.font.headline, { color: t.text, marginBottom: 10 }]}>Platform</Text>
          <PlatformPicker value={platform} onChange={setPlatform} />
        </Card>

        <Card style={{ marginTop: 16 }}>
          <Text style={[t.font.headline, { color: t.text, marginBottom: 10 }]}>Trip Details</Text>
          <NumberField label="Trip pay ($)" value={pay} onChangeText={setPay} placeholder="0.00" />
          <NumberField label="Distance (mi)" value={distance} onChangeText={setDistance} placeholder="0.0" />
          <NumberField label="Time (min)" value={minutes} onChangeText={setMinutes} placeholder="0" />
        </Card>

        <Card style={{ marginTop: 16, alignItems: 'center' }}>
          <Text style={[t.font.caption, { color: t.textMuted }]}>NET PROFIT</Text>
          <CountUp value={result.net} prefix="$" style={[t.font.largeTitle, { color: t.text, marginVertical: 4 }]} />
          <VerdictChip perHour={result.perHour} threshold={threshold} />

          <View style={styles.statsRow}>
            <View style={styles.statCell}>
              <Text style={[t.font.caption, { color: t.textMuted }]}>PER HOUR</Text>
              <Text style={[t.font.headline, { color: t.text }]}>${result.perHour.toFixed(2)}</Text>
            </View>
            <View style={styles.statCell}>
              <Text style={[t.font.caption, { color: t.textMuted }]}>PER MILE</Text>
              <Text style={[t.font.headline, { color: t.text }]}>${result.perMile.toFixed(2)}</Text>
            </View>
            <View style={styles.statCell}>
              <Text style={[t.font.caption, { color: t.textMuted }]}>EXPENSES</Text>
              <Text style={[t.font.headline, { color: t.text }]}>${result.expenses.toFixed(2)}</Text>
            </View>
          </View>
        </Card>

        <Button
          label={blocked ? 'Upgrade to Pro' : saving ? 'Saving…' : 'Save Trip'}
          onPress={blocked ? () => navigation.getParent()?.navigate('Pro') : onSave}
          disabled={!blocked && (!canSave || saving)}
          style={{ marginTop: 20, marginBottom: 40 }}
        />
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  gearBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginTop: 16,
  },
  statCell: {
    alignItems: 'center',
    flex: 1,
  },
});
