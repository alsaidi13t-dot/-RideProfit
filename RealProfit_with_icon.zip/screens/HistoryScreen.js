import React, { useMemo } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTheme } from '../ui/theme';
import { Screen, Card } from '../ui/kit';
import { useApp } from '../store/AppContext';
import TripRow from '../components/TripRow';
import PlatformBars from '../components/PlatformBars';

export default function HistoryScreen({ navigation }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { trips, loading } = useApp();

  const totals = useMemo(() => {
    const net = trips.reduce((sum, tr) => sum + (Number(tr?.net_profit) || 0), 0);
    const count = trips.length;
    return { net, count };
  }, [trips]);

  return (
    <Screen>
      <FlatList
        data={trips}
        keyExtractor={(item, idx) => String(item?.id ?? idx)}
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 16 }]}
        ListHeaderComponent={
          <View>
            <Text style={[t.font.largeTitle, { color: t.text }]}>History</Text>
            <Text style={[t.font.subhead, { color: t.textMuted, marginBottom: 16 }]}>
              {totals.count} trip{totals.count === 1 ? '' : 's'} · ${totals.net.toFixed(2)} net
            </Text>

            {trips.length > 0 && (
              <Card style={{ marginBottom: 16 }}>
                <Text style={[t.font.headline, { color: t.text, marginBottom: 10 }]}>By Platform</Text>
                <PlatformBars trips={trips} />
              </Card>
            )}
          </View>
        }
        renderItem={({ item }) => (
          <TripRow
            trip={item}
            onPress={() => navigation.navigate('TripDetail', { tripId: item.id })}
          />
        )}
        ListEmptyComponent={
          !loading && (
            <Card>
              <Text style={[t.font.subhead, { color: t.textMuted, textAlign: 'center' }]}>
                No trips logged yet. Calculate a trip to see it here.
              </Text>
            </Card>
          )
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
});
