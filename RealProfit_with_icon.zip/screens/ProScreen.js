import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { useTheme } from '../ui/theme';
import { Screen, Card, Button } from '../ui/kit';
import { useApp } from '../store/AppContext';
import EmptyState from '../components/EmptyState';

const FEATURES = [
  { icon: 'infinite', title: 'Unlimited calculations', desc: 'No more daily caps — calculate every trip you take.' },
  { icon: 'stats-chart', title: 'Deeper history', desc: 'See trends across every platform you drive or deliver for.' },
  { icon: 'notifications', title: 'Daily reminders', desc: 'Get nudged to log trips so your numbers stay accurate.' },
  { icon: 'shield-checkmark', title: 'Priority support', desc: "We'll help you get the most out of every shift." },
];

export default function ProScreen({ navigation }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { isPro, updateSettings, trips } = useApp();
  const [loading, setLoading] = useState(false);

  const onUpgrade = async () => {
    setLoading(true);
    try {
      await updateSettings({ is_pro: true, plan: 'pro' });
      Alert.alert('Welcome to Pro', 'Unlimited calculations are now unlocked.');
    } catch (e) {
      Alert.alert('Could not upgrade', e?.message || 'Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const onRestore = async () => {
    setLoading(true);
    try {
      await updateSettings({ is_pro: false, plan: 'free' });
      Alert.alert('Restored', 'You are back on the free plan.');
    } catch (e) {
      Alert.alert('Could not save', 'Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const items = trips || [];

  return (
    <Screen>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 16 }]}>
        <View style={styles.headerRow}>
          <View>
            <Text style={[t.font.largeTitle, { color: t.text }]}>Go Pro</Text>
            <Text style={[t.font.subhead, { color: t.textMuted }]}>
              {isPro ? "You're already on Pro" : 'Unlock the full toolkit'}
            </Text>
          </View>
          <View style={[styles.badge, { backgroundColor: t.accent }]}>
            <Ionicons name="flash" size={18} color="#000" />
          </View>
        </View>

        <Card style={{ marginTop: 16 }}>
          {FEATURES.map((f, idx) => (
            <View key={f.title} style={[styles.featureRow, idx > 0 && { marginTop: 14 }]}>
              <View style={[styles.iconWrap, { backgroundColor: t.surfaceAlt || t.surface }]}>
                <Ionicons name={f.icon} size={20} color={t.accent} />
              </View>
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={[t.font.headline, { color: t.text }]}>{f.title}</Text>
                <Text style={[t.font.caption, { color: t.textMuted, marginTop: 2 }]}>{f.desc}</Text>
              </View>
            </View>
          ))}
        </Card>

        <Card style={{ marginTop: 16, alignItems: 'center' }}>
          <Text style={[t.font.largeTitle, { color: t.text }]}>$4.99/mo</Text>
          <Text style={[t.font.caption, { color: t.textMuted, marginTop: 4 }]}>Cancel anytime</Text>
        </Card>

        {isPro ? (
          <Button label="Restore Free Plan" onPress={onRestore} disabled={loading} style={{ marginTop: 20 }} />
        ) : (
          <Button label={loading ? 'Upgrading…' : 'Upgrade to Pro'} onPress={onUpgrade} disabled={loading} style={{ marginTop: 20 }} />
        )}

        <Button
          label="Your Numbers"
          onPress={() => navigation.navigate('ProSettings')}
          variant="secondary"
          style={{ marginTop: 12, marginBottom: 20 }}
        />

        <Card style={{ marginTop: 4, marginBottom: 40 }}>
          <Text style={[t.font.headline, { color: t.text, marginBottom: 10 }]}>Your Trips</Text>
          {items.length === 0 ? (
            <EmptyState
              title="No records yet"
              body="Add your first to see it here."
            />
          ) : (
            items.map((trip) => (
              <View key={trip.id} style={styles.tripRow}>
                <Text style={[t.font.subhead, { color: t.text }]}>{trip.platform}</Text>
                <Text style={[t.font.subhead, { color: t.textMuted }]}>
                  ${Number(trip.net_profit || 0).toFixed(2)}
                </Text>
              </View>
            ))
          )}
        </Card>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  badge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tripRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
});
