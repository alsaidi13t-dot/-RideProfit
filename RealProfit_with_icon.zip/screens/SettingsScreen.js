import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';

import { useTheme } from '../ui/theme';
import { Screen, Card, Button } from '../ui/kit';
import { useApp } from '../store/AppContext';
import { num, DEFAULT_THRESHOLD } from '../lib/calc';
import NumberField from '../components/NumberField';
import Slider from '../components/Slider';

export default function SettingsScreen() {
  const t = useTheme();
  const { settings, updateSettings } = useApp();

  const [gasPrice, setGasPrice] = useState(String(settings.gas_price ?? ''));
  const [mpg, setMpg] = useState(String(settings.mpg ?? ''));
  const [maint, setMaint] = useState(String(settings.maint_per_mile ?? ''));
  const [threshold, setThreshold] = useState(num(settings.threshold) || DEFAULT_THRESHOLD);
  const [saving, setSaving] = useState(false);

  const onSave = async () => {
    setSaving(true);
    try {
      await updateSettings({
        gas_price: num(gasPrice),
        mpg: num(mpg),
        maint_per_mile: num(maint),
        threshold: num(threshold),
      });
      Alert.alert('Saved', 'Your numbers have been updated.');
    } catch (e) {
      Alert.alert('Could not save', e?.message || 'Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Card>
          <Text style={[t.font.headline, { color: t.text, marginBottom: 10 }]}>Vehicle Costs</Text>
          <NumberField label="Gas price ($/gal)" value={gasPrice} onChangeText={setGasPrice} placeholder="3.49" />
          <NumberField label="Fuel efficiency (mpg)" value={mpg} onChangeText={setMpg} placeholder="30" />
          <NumberField label="Maintenance ($/mile)" value={maint} onChangeText={setMaint} placeholder="0.10" />
        </Card>

        <Card style={{ marginTop: 16 }}>
          <Text style={[t.font.headline, { color: t.text, marginBottom: 6 }]}>Good Trip Threshold</Text>
          <Text style={[t.font.subhead, { color: t.textMuted, marginBottom: 10 }]}>
            Trips paying ${threshold.toFixed(0)}/hr or more are marked as good.
          </Text>
          <Slider
            value={threshold}
            onChange={setThreshold}
            minimumValue={5}
            maximumValue={60}
            step={1}
          />
        </Card>

        <Button
          label={saving ? 'Saving…' : 'Save Changes'}
          onPress={onSave}
          disabled={saving}
          style={{ marginTop: 20, marginBottom: 40 }}
        />
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 24,
  },
});
