import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTheme } from '../ui/theme';
import { Screen, Card, Button } from '../ui/kit';
import { useApp } from '../store/AppContext';
import { PLATFORMS } from '../lib/platforms';
import VerdictChip from '../components/VerdictChip';

export default function TripDetailScreen({ route, navigation }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { trips, removeTrip, threshold } = useApp();
  const { tripId } = route.params || {};

  const trip = useMemo(() => trips.find((tr) => tr?.id === tripId), [trips, tripId]);

  const platform = PLATFORMS.find((p) => p.id === trip?.platform);

  if (!trip) {
    return (
      <Screen>
        <View style={[styles.content, { paddingTop: insets.top + 16 }]}>
          <Text style={[t.font.subhead, { color: t.textMuted }]}>Trip not found.</Text>
        </View>
      </Screen>
    );
  }

  const onDelete = () => {
    Alert.alert('Delete trip?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await removeTrip(trip.id);
            navigation.goBack();
          } catch (e) {
            Alert.alert('Could not save', 'Please try again.');
          }
        },
      },
    ]);
  };

  const dateStr = trip.logged_at ? new Date(trip.logged_at).toLocaleString() : '';

  return (
    <Screen>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 16 }]}>
        <Card style={{ alignItems: 'center' }}>
          <Text style={[t.font.caption, { color: t.textMuted }]}>{platform?.label || trip.platform}</Text>
          <Text style={[t.font.largeTitle, { color: t.text, marginVertical: 6 }]}>
            ${Number(trip.net_profit || 0).toFixed(2)}
          </Text>
          <VerdictChip perHour={Number(trip.per_hour || 0)} threshold={threshold} />
          <Text style={[t.font.caption, { color: t.textMuted, marginTop: 10 }]}>{dateStr}</Text>
        </Card>

        <Card style={{ marginTop: 16 }}>
          <Text style={[t.font.headline, { color: t.text, marginBottom: 10 }]}>Trip Numbers</Text>
          <Row label="Trip pay" value={`$${Number(trip.trip_pay || 0).toFixed(2)}`} t={t} />
          <Row label="Distance" value={`${Number(trip.distance || 0).toFixed(1)} mi`} t={t} />
          <Row label="Time" value={`${Number(trip.minutes || 0).toFixed(0)} min`} t={t} />
          <Row label="Per hour" value={`$${Number(trip.per_hour || 0).toFixed(2)}`} t={t} />
          <Row label="Per mile" value={`$${Number(trip.per_mile || 0).toFixed(2)}`} t={t} />
        </Card>

        <Card style={{ marginTop: 16 }}>
          <Text style={[t.font.headline, { color: t.text, marginBottom: 10 }]}>Expenses</Text>
          <Row label="Fuel cost" value={`$${Number(trip.fuel_cost || 0).toFixed(2)}`} t={t} />
          <Row label="Maintenance" value={`$${Number(trip.maint_cost || 0).toFixed(2)}`} t={t} />
          <Row label="Total expenses" value={`$${Number(trip.total_expenses || 0).toFixed(2)}`} t={t} />
        </Card>

        <Button label="Delete Trip" onPress={onDelete} variant="destructive" style={{ marginTop: 20, marginBottom: 40 }} />
      </ScrollView>
    </Screen>
  );
}

function Row({ label, value, t }) {
  return (
    <View style={styles.row}>
      <Text style={[t.font.subhead, { color: t.textMuted }]}>{label}</Text>
      <Text style={[t.font.subhead, { color: t.text }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
});
