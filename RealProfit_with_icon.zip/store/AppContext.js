import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { saveRecord, listRecords, updateRecord, deleteRecord } from '../lib/wron-db';
import {
  computeTrip,
  dayKey,
  DEFAULT_GAS_PRICE,
  DEFAULT_GOAL,
  DEFAULT_MAINT,
  DEFAULT_MPG,
  DEFAULT_THRESHOLD,
  FREE_LIMIT,
  num,
} from '../lib/calc';

export const DEFAULT_SETTINGS = {
  gas_price: DEFAULT_GAS_PRICE,
  mpg: DEFAULT_MPG,
  maint_per_mile: DEFAULT_MAINT,
  threshold: DEFAULT_THRESHOLD,
  daily_goal: DEFAULT_GOAL,
  is_pro: false,
  plan: 'free',
  reminder_enabled: false,
  reminder_id: '',
  reminder_hour: 20,
  reminder_minute: 30,
  seeded: false,
};

const FALLBACK = {
  settings: DEFAULT_SETTINGS,
  trips: [],
  loading: true,
  error: '',
  isPro: false,
  today: dayKey(new Date()),
  todayCount: 0,
  remaining: FREE_LIMIT,
  threshold: DEFAULT_THRESHOLD,
  refresh: async () => {},
  addTrip: async () => null,
  removeTrip: async () => {},
  clearTrips: async () => {},
  updateSettings: async () => {},
};

const AppContext = createContext(FALLBACK);

export function useApp() {
  return useContext(AppContext) || FALLBACK;
}

// ---------------------------------------------------------------- seed data
const SEED = [
  { platform: 'uber', trip_pay: 18.4, distance: 9.2, minutes: 24, daysAgo: 1, hour: 18 },
  { platform: 'doordash', trip_pay: 7.25, distance: 6.8, minutes: 22, daysAgo: 1, hour: 12 },
  { platform: 'lyft', trip_pay: 26.9, distance: 14.1, minutes: 31, daysAgo: 2, hour: 20 },
  { platform: 'instacart', trip_pay: 31.5, distance: 11.4, minutes: 52, daysAgo: 2, hour: 10 },
  { platform: 'ubereats', trip_pay: 9.8, distance: 4.3, minutes: 17, daysAgo: 3, hour: 19 },
  { platform: 'uber', trip_pay: 12.6, distance: 5.5, minutes: 15, daysAgo: 4, hour: 8 },
  { platform: 'doordash', trip_pay: 5.5, distance: 7.9, minutes: 26, daysAgo: 4, hour: 13 },
  { platform: 'lyft', trip_pay: 41.2, distance: 22.6, minutes: 44, daysAgo: 5, hour: 16 },
  { platform: 'uber', trip_pay: 15.75, distance: 7.1, minutes: 19, daysAgo: 6, hour: 21 },
];

function buildSeedRows() {
  return SEED.map((s) => {
    const d = new Date();
    d.setDate(d.getDate() - s.daysAgo);
    d.setHours(s.hour, 15, 0, 0);
    const gas = 3.39;
    const mpg = 30;
    const maint = 0.1;
    const res = computeTrip({
      pay: s.trip_pay,
      distance: s.distance,
      minutes: s.minutes,
      gasPrice: gas,
      mpg,
      maintPerMile: maint,
    });
    return {
      platform: s.platform,
      trip_pay: s.trip_pay,
      distance: s.distance,
      minutes: s.minutes,
      gas_price: gas,
      mpg,
      maint_per_mile: maint,
      fuel_cost: res.fuel,
      maint_cost: res.maint,
      total_expenses: res.expenses,
      net_profit: res.net,
      per_hour: res.perHour,
      per_mile: res.perMile,
      verdict: res.perHour >= DEFAULT_THRESHOLD ? 'good' : 'low',
      day_key: dayKey(d),
      logged_at: d.toISOString(),
    };
  });
}

function tripTime(tr) {
  const raw = tr?.logged_at || tr?.created_at;
  const t = raw ? new Date(raw).getTime() : 0;
  return Number.isFinite(t) ? t : 0;
}

function sortTrips(rows) {
  return (Array.isArray(rows) ? rows.slice() : []).sort((a, b) => tripTime(b) - tripTime(a));
}

// ---------------------------------------------------------------- provider
export function AppProvider({ children }) {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [settingsId, setSettingsId] = useState(null);
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [today, setToday] = useState(dayKey(new Date()));
  const mounted = useRef(true);

  // The free limit resets at local midnight — keep the day key fresh.
  useEffect(() => {
    const id = setInterval(() => {
      const k = dayKey(new Date());
      setToday((prev) => (prev === k ? prev : k));
    }, 30000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => () => { mounted.current = false; }, []);

  const load = useCallback(async () => {
    try {
      const rows = await listRecords('settings');
      let s = Array.isArray(rows) && rows.length ? rows[0] : null;
      if (!s) {
        s = await saveRecord('settings', { ...DEFAULT_SETTINGS });
      }
      if (!mounted.current) return;
      setSettingsId(s?.id || null);
      setSettings({ ...DEFAULT_SETTINGS, ...(s || {}) });

      let tripRows = await listRecords('trips');
      tripRows = Array.isArray(tripRows) ? tripRows : [];

      if (!s?.seeded && tripRows.length === 0) {
        const seeds = buildSeedRows();
        for (let i = 0; i < seeds.length; i++) {
          try {
            const saved = await saveRecord('trips', seeds[i]);
            if (saved) tripRows.push(saved);
          } catch (e) {
            // a failed seed row is not worth blocking the app for
          }
        }
        if (s?.id) {
          try {
            await updateRecord('settings', s.id, { seeded: true });
            if (mounted.current) setSettings((prev) => ({ ...prev, seeded: true }));
          } catch (e) {
            // ignore
          }
        }
      }

      if (!mounted.current) return;
      setTrips(sortTrips(tripRows));
      setError('');
    } catch (e) {
      if (mounted.current) setError(e?.message || 'We could not reach your saved data.');
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const refresh = useCallback(async () => {
    try {
      const [sRows, tRows] = await Promise.all([listRecords('settings'), listRecords('trips')]);
      if (!mounted.current) return;
      const s = Array.isArray(sRows) && sRows.length ? sRows[0] : null;
      if (s) {
        setSettingsId(s.id);
        setSettings({ ...DEFAULT_SETTINGS, ...s });
      }
      setTrips(sortTrips(tRows));
      setError('');
    } catch (e) {
      if (mounted.current) setError(e?.message || 'Refresh failed.');
      throw e;
    }
  }, []);

  const updateSettings = useCallback(async (patch) => {
    const clean = patch || {};
    setSettings((prev) => ({ ...prev, ...clean }));
    try {
      if (settingsId) {
        const row = await updateRecord('settings', settingsId, clean);
        if (row && mounted.current) setSettings((prev) => ({ ...prev, ...row }));
      } else {
        const row = await saveRecord('settings', { ...DEFAULT_SETTINGS, ...clean });
        if (row && mounted.current) {
          setSettingsId(row.id);
          setSettings({ ...DEFAULT_SETTINGS, ...row });
        }
      }
    } catch (e) {
      throw new Error(e?.message || 'Your change could not be saved.');
    }
  }, [settingsId]);

  const addTrip = useCallback(async (values) => {
    const row = await saveRecord('trips', values);
    if (row && mounted.current) setTrips((prev) => sortTrips([row, ...prev]));
    return row;
  }, []);

  const removeTrip = useCallback(async (id) => {
    await deleteRecord('trips', id);
    if (mounted.current) setTrips((prev) => prev.filter((tr) => tr?.id !== id));
  }, []);

  const clearTrips = useCallback(async () => {
    const ids = trips.map((tr) => tr?.id).filter(Boolean);
    for (let i = 0; i < ids.length; i++) {
      await deleteRecord('trips', ids[i]);
    }
    if (mounted.current) setTrips([]);
  }, [trips]);

  const isPro = !!settings?.is_pro;
  const todayCount = useMemo(
    () => trips.filter((tr) => tr?.day_key === today).length,
    [trips, today],
  );
  const remaining = isPro ? Infinity : Math.max(0, FREE_LIMIT - todayCount);
  const threshold = num(settings?.threshold) > 0 ? num(settings.threshold) : DEFAULT_THRESHOLD;

  const value = useMemo(() => ({
    settings: settings || DEFAULT_SETTINGS,
    trips: trips || [],
    loading,
    error,
    isPro,
    today,
    todayCount,
    remaining,
    threshold,
    refresh,
    addTrip,
    removeTrip,
    clearTrips,
    updateSettings,
  }), [settings, trips, loading, error, isPro, today, todayCount, remaining, threshold, refresh, addTrip, removeTrip, clearTrips, updateSettings]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
