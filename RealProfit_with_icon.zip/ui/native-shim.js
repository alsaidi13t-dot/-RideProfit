import { Platform as ShimPlatform, TurboModuleRegistry as ShimRegistry, NativeModules as ShimNativeModules, StyleSheet as ShimStyleSheet } from 'react-native';

if (ShimPlatform.OS === 'web') {
  // Web-preview guard for the "Cannot set indexed properties on this object"
  // red screen (Chrome: "Failed to set an indexed property [0] on
  // 'CSSStyleDeclaration'"). Proven with a debugger on the real player
  // (2026-09-08): react-native-svg's web bundle hands React DOM the style prop
  // as written, React DOM's style setter walks an ARRAY's keys and writes
  // style["0"] on the SVG node, the browser rejects it, and the whole preview
  // dies at first render with no file or stack. Every element passes through
  // createElement / jsx, so flatten a style array for DOM-tag elements there.
  // React Native's own components never reach this branch (their style is
  // resolved before the DOM tag is created). This module is the entry's first
  // import, so it runs before react-native-svg or any screen is evaluated.
  try {
    const flat = (s) => {
      if (!Array.isArray(s)) return s;
      try { const f = ShimStyleSheet.flatten(s); if (f && typeof f === 'object' && !Array.isArray(f)) return f; } catch (e) {}
      const out = {};
      const walk = (x) => { if (!x) return; if (Array.isArray(x)) { for (let i = 0; i < x.length; i++) walk(x[i]); } else if (typeof x === 'object') Object.assign(out, x); };
      walk(s);
      return out;
    };
    const applied = [];
    const guard = (mod, key, label) => {
      const orig = mod ? mod[key] : null;
      if (typeof orig !== 'function') return;
      if (orig.__wronStyleGuard) { applied.push(label); return; }
      const wrapped = function () {
        // Hot path for every element of every render: decide with two reads
        // and only copy arguments in the rare svg-array case.
        const type = arguments[0], props = arguments[1];
        if (props && Array.isArray(props.style) && (typeof type === 'string' || (type && typeof type === 'object' && typeof type.type === 'string'))) {
          const args = Array.prototype.slice.call(arguments);
          const next = Object.assign({}, props);
          next.style = flat(props.style);
          args[1] = next;
          return orig.apply(this, args);
        }
        return orig.apply(this, arguments);
      };
      wrapped.__wronStyleGuard = true;
      try { mod[key] = wrapped; } catch (e) { return; }
      if (mod[key] === wrapped) applied.push(label);
    };
    const guardMod = (mod, name, keys) => {
      if (!mod) return;
      for (let i = 0; i < keys.length; i++) {
        guard(mod, keys[i], name + '.' + keys[i]);
        if (mod.default && mod.default !== mod && typeof mod.default === 'object') guard(mod.default, keys[i], name + '.default.' + keys[i]);
      }
    };
    // Literal module names only: the preview's module loader resolves
    // require() statically and a computed name throws (measured).
    let reactMod = null, jsxMod = null;
    try { reactMod = require('react'); } catch (e) {}
    try { jsxMod = require('react/jsx-runtime'); } catch (e) {}
    guardMod(reactMod, 'react', ['createElement', 'cloneElement']);
    guardMod(jsxMod, 'react/jsx-runtime', ['jsx', 'jsxs']);
    globalThis.__wronStyleGuard = applied.length ? applied.join(',') : 'none';
  } catch (e) {
    try { globalThis.__wronStyleGuard = 'error'; } catch (x) {}
  }
}

if (ShimPlatform.OS !== 'web') {
  try {
    const g = globalThis;
    // ONLY inside Expo Go. This proxy exists because Expo Go 57 renamed modules
    // the SDK 54 bundle asks for; a standalone build has no such mismatch and
    // installing it there is actively harmful, for two reasons:
    //
    //  1. TurboModuleRegistry.get() RESOLVES THROUGH global.__turboModuleProxy.
    //     So on a miss this function called hostGet -> TurboModuleRegistry.get
    //     -> this function -> ... In Expo Go the original proxy nearly always
    //     resolves, so the loop never ran. In a standalone build one missing
    //     module is unbounded recursion at startup.
    //  2. The global error handler installed below then swallows the crash, so
    //     the app dies to a BLACK SCREEN with no red box and nothing in the log.
    //
    // Reported on TestFlight builds of every generated app (2026-09-17).
    const standalone = (function () {
      try {
        // eslint-disable-next-line
        const C = require('expo-constants');
        const c = (C && (C.default || C)) || {};
        const env = c.executionEnvironment;
        if (env) return env !== 'storeClient';
        if (c.appOwnership) return c.appOwnership !== 'expo';
      } catch (e) {}
      return false;
    })();

    if (!standalone) {
      const orig = typeof g.__turboModuleProxy === 'function' ? g.__turboModuleProxy : null;
      let inGet = false;
      const hostGet = (name) => {
        if (inGet) return null;              // re-entry: the registry is asking US
        inGet = true;
        try { return ShimRegistry.get(name); } catch (e) { return null; } finally { inGet = false; }
      };
      g.__turboModuleProxy = (name) => {
        let m = null;
        try { m = orig ? orig(name) : null; } catch (e) {}
        if (!m) m = hostGet(name);
        if (!m && ShimNativeModules && ShimNativeModules[name]) m = ShimNativeModules[name];
        if (!m && name === 'PlatformConstants') m = { getConstants: () => ({ ...(ShimPlatform.constants || {}) }) };
        return m;
      };
      g.__wronNativeShim = 1;
    } else {
      g.__wronNativeShim = 0;
    }
  } catch (e) {}

  try {
    const g = globalThis;
    const spurious = (e) => /Unsupported top level event type "topSvg[A-Za-z]*"/.test(String(e && e.message ? e.message : e));
    g.__wronIsSpuriousError = spurious;
    if (typeof ErrorUtils !== 'undefined' && ErrorUtils && ErrorUtils.getGlobalHandler && ErrorUtils.setGlobalHandler) {
      const prev = ErrorUtils.getGlobalHandler();
      ErrorUtils.setGlobalHandler((e, isFatal) => {
        if (spurious(e)) return;
        if (typeof prev === 'function') prev(e, isFatal);
      });
    }
    if (typeof g.RN$registerExceptionListener === 'function') {
      g.RN$registerExceptionListener((data) => {
        try { if (data && spurious(data) && typeof data.preventDefault === 'function') data.preventDefault(); } catch (x) {}
      });
    }
  } catch (e) {}

}
